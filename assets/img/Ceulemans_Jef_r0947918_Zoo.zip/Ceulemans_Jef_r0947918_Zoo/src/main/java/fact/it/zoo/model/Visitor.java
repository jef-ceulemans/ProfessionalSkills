/*Jef Ceulemans r0947918 */
package fact.it.zoo.model;

import java.util.ArrayList;

public class Visitor extends Person {

    private  String personalCode="undefined";
    private int yearOfBirth;
    private ArrayList<String> wishList = new ArrayList<>();


    public Visitor(String firstName, String surName) {
        super(firstName, surName);

    }


    public String getPersonalCode() {

        return personalCode;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }



    public ArrayList<String> getWishList() {
        return wishList;
    }

    public void setPersonalCode(String personalCode) {

        if (this.personalCode.equals("undefined")){
            this.personalCode = personalCode;
        }



    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public Boolean addToWishList(String animal) {

        boolean check = false;
        if (wishList.size() >= 5) {
            check = false;
        } else {
            wishList.add(animal);
            check=true;
        }
    return check;
        }

    public int getNumberOfWishes(){

        return wishList.size();
    }

        public String toString(){
        String result="Visitor " +super.toString()+" with personal code "+personalCode;
        return result;
        }

}
