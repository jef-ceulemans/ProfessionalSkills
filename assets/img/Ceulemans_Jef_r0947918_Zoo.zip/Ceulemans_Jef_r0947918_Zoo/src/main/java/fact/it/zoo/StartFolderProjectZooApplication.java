package fact.it.zoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartFolderProjectZooApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartFolderProjectZooApplication.class, args);
	}

}
