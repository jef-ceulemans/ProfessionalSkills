/*Jef Ceulemans r0947918*/
package fact.it.zoo.model;

import java.util.ArrayList;

public class Zoo {

    private String name;
    private int numberVisitors;

    private ArrayList< AnimalWorld >animalWorlds = new ArrayList<>();

    public Zoo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumberVisitors() {
        return numberVisitors;
    }

    public ArrayList<AnimalWorld> getAnimalWorlds() {
        return animalWorlds;
    }

    public int getNumberOfAnimalWorlds(){
        return animalWorlds.size();
    }

    public void addAnimalWorld(AnimalWorld animalWorld){
        animalWorlds.add(animalWorld);
    }

    public AnimalWorld searchAnimalWorldByName(String name){

        String inspect =null;
        AnimalWorld res=null;
        while (inspect==null){

            for (AnimalWorld animalWorld: animalWorlds) {
                String newName = animalWorld.getName();
                if (newName.equals(name)) {
                    res = animalWorld;
                    inspect = "checked";
                }
            }
            if (inspect==null){
                inspect="checked";
            }
        }
        return res;
    }

    public void registerVisitor(Visitor visitor){

        numberVisitors+=1;
        visitor.setPersonalCode(name.substring(0,2)+numberVisitors);
    }

}
