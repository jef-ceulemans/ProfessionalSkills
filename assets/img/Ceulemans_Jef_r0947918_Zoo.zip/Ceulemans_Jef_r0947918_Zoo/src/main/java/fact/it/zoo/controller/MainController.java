/*Jef Ceulemans r0947918*/
package fact.it.zoo.controller;
import org.springframework.ui.Model;
import fact.it.zoo.model.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


@Controller
public class MainController{

    private ArrayList<Staff> staffArrayList =new ArrayList<>();
    private ArrayList<Visitor> visitorArrayList=new ArrayList<>();
    private ArrayList<Zoo> zooArrayList= new ArrayList<>();

    @PostConstruct void fillData() {
        staffArrayList.addAll(fillStaffMembers());
        visitorArrayList.addAll(fillVisitors());
        zooArrayList.addAll(fillZoos());

}

//Write your code here

    @RequestMapping("/1_AddNewVisitor")
    public String AddNewVisitor(Model model){
        model.addAttribute("zoos", zooArrayList);
        return "1_AddNewVisitor";

    }

    @RequestMapping("/2_WelcomeVisitor")
    public String WelcomeVisitor(){

        return "2_WelcomeVisitor";
    }

    @RequestMapping("/SubmitNewVisitor")
    public String SubmitNewVisitor(HttpServletRequest request, Model model){
        String firstName=request.getParameter("firstName");
        String surName=request.getParameter("surName");
        int zooIndex =Integer.parseInt(request.getParameter("zoo"));
        int yearOfBirth =Integer.parseInt(request.getParameter("yearOfBirth"));

        Visitor visitor = new Visitor(firstName, surName);
        visitor.setYearOfBirth(yearOfBirth);
        model.addAttribute("visitor", visitor);
        Zoo zoo=zooArrayList.get(zooIndex);
        zoo.registerVisitor(visitor);
        visitorArrayList.add(visitor);
        return "2_WelcomeVisitor";
    }

    @RequestMapping ("/3_AddNewStaffMember")
    public String AddNewStaffMember(){

        return "3_AddNewStaffMember";
    }



    @RequestMapping("/SubmitNewStaffMember")
    public String SubmitNewStaffMember(HttpServletRequest request, Model model){
        DateTimeFormatter dt =DateTimeFormatter.ofPattern("dd/MM/yyyy");

        String firstName=request.getParameter("firstName");
        String surName=request.getParameter("surName");
        LocalDate employeedSince=LocalDate.parse(request.getParameter("employeedSince"),dt);
        boolean workingStudent=(request.getParameter("workingStudent")!=null);

        Staff staff =new Staff(firstName,surName);
        staff.setStartDate(employeedSince);
        staff.setStudent(workingStudent);
        model.addAttribute("staff", staff);
        staffArrayList.add(staff);

        return "4_StaffMemberInfo";

    }

    @RequestMapping("/4_StaffMemberInfo")
    public String StaffMemberInfo(){

        return "4_StaffMemberInfo";
    }


    @RequestMapping("/5_ShowStaffMembers")
    public String ShowStaffMembers(Model model){
        model.addAttribute("staffArrayList",staffArrayList);
        return "5_ShowStaffMembers";
    }

    @RequestMapping("/6_ShowVisitors")
    public String ShowVisitors(Model model){
        model.addAttribute("visitorArrayList",visitorArrayList);
        return "6_ShowVisitors";
    }

    @RequestMapping("/7_AddNewZoo")
    public String AddNewZoo(){

        return "7_AddNewZoo";
    }

    @RequestMapping("/SubmitNewZoo")
    public String SubmitNewZoo(HttpServletRequest request, Model model){
        String ZooName=request.getParameter("NameZoo");
        Zoo zoo =new Zoo(ZooName);

        model.addAttribute("zooArrayList",zooArrayList);
        zooArrayList.add(zoo);
        return "8_ShowZoos";
    }

    @RequestMapping("/8_ShowZoos")
    public String ShowZoos(Model model){
        model.addAttribute("zooArrayList", zooArrayList);
        return "8_ShowZoos";
    }

    @RequestMapping("/9_AddNewAnimalWorld")
        public String AddNewAnimalWorld(Model model){
        model.addAttribute("zooArrayList",zooArrayList);
        model.addAttribute("staffArrayList",staffArrayList);
        return "9_AddNewAnimalWorld";
    }

    @RequestMapping("/hyperlink")
    public String hyperlink(HttpServletRequest request, Model model){
        int hyperlink=Integer.parseInt(request.getParameter("hyperlink"));

        Zoo zoo=zooArrayList.get(hyperlink);
        model.addAttribute("zoo",zoo);
        return "10_ShowAnimalWorldsOfZoo";
    }


    @RequestMapping("/SubmitNewAnimalWorld")
        public String SubmitNewAnimalWorld(HttpServletRequest request, Model model){
        String nameAnimalWorldBefore=request.getParameter("nameAnimalWorld");
        String nameAnimalWorld=nameAnimalWorldBefore.substring(0,1).toUpperCase()+nameAnimalWorldBefore.substring(1).toLowerCase();
        int numberOfAnimals=Integer.parseInt(request.getParameter("numberOfAnimals"));
        String photo=request.getParameter("photo");
        int wichZoo=Integer.parseInt(request.getParameter("wichZoo"));
        int whoResponsibleThisAnimalWorld=Integer.parseInt(request.getParameter("whoResponsibleThisAnimalWorld"));
        if (wichZoo < 0){
            model.addAttribute("errormessage","You didn't choose a zoo!");
            return "/error";
        }
        if (whoResponsibleThisAnimalWorld < 0){
            model.addAttribute("errormessage","You didn't choose a staff member!");
            return "/error";
        }

        AnimalWorld animalWorld=new AnimalWorld(nameAnimalWorld);
        animalWorld.setNumberOfAnimals(numberOfAnimals);
        animalWorld.setPhoto("/img/"+photo+".jpg");
        animalWorld.setResponsible(staffArrayList.get(whoResponsibleThisAnimalWorld));
        zooArrayList.get(wichZoo).addAnimalWorld(animalWorld);
        Zoo zoo=zooArrayList.get(wichZoo);
        model.addAttribute("animalWorld",animalWorld);
        model.addAttribute("zoo",zoo);

        return "10_ShowAnimalWorldsOfZoo";
    }

    @RequestMapping("/10_ShowAnimalWorldsOfZoo")
    public String ShowAnimalWorldsOfZoo(Model model){
        model.addAttribute("zooArrayList",zooArrayList);
        model.addAttribute("staffArrayList",staffArrayList);
        return "10_ShowAnimalWorldsOfZoo";
    }


    @RequestMapping("/11_SearchAnimalWorld")
    public String SearchAnimalWorld(Model model){
        model.addAttribute("zooArrayList",zooArrayList);
        return "11_SearchAnimalWorld";
    }

    @RequestMapping("/searchAnimalWorld")
    public String searchAnimalWorld(HttpServletRequest request, Model model){
    String searchWithoutCapital=request.getParameter("searchAnimalWorld");
    String search=searchWithoutCapital.substring(0,1).toUpperCase()+searchWithoutCapital.substring(1).toLowerCase();
    AnimalWorld foundAnimalWorld=null;
    while (foundAnimalWorld==null){
        for (Zoo zoo : zooArrayList){
            AnimalWorld searchedAnimalWorld=zoo.searchAnimalWorldByName(search);
            if (searchedAnimalWorld!=null){
                foundAnimalWorld=zoo.searchAnimalWorldByName(search);
            }}
        if (foundAnimalWorld==null){
            model.addAttribute("errormessage","There is no animal with the name '"+search+"'");
            return "/error";

        }
    }

    model.addAttribute("foundAnimalWorld",foundAnimalWorld);
    return "11_SearchAnimalWorld";
    }



   private ArrayList<Staff> fillStaffMembers() {
        ArrayList<Staff> staffMembers = new ArrayList<>();

        Staff staff1 = new Staff("Johan", "Bertels");
        staff1.setStartDate(LocalDate.of(2002, 5, 1));
        Staff staff2 = new Staff("An", "Van Herck");
        staff2.setStartDate(LocalDate.of(2019, 3, 15));
        staff2.setStudent(true);
        Staff staff3 = new Staff("Bruno", "Coenen");
        staff3.setStartDate(LocalDate.of(1995,1,1));
        Staff staff4 = new Staff("Wout", "Dayaert");
        staff4.setStartDate(LocalDate.of(2002, 12, 15));
        Staff staff5 = new Staff("Louis", "Petit");
        staff5.setStartDate(LocalDate.of(2020, 8, 1));
        staff5.setStudent(true);
        Staff staff6 = new Staff("Jean", "Pinot");
        staff6.setStartDate(LocalDate.of(1999,4,1));
        Staff staff7 = new Staff("Ahmad", "Bezeri");
        staff7.setStartDate(LocalDate.of(2009, 5, 1));
        Staff staff8 = new Staff("Hans", "Volzky");
        staff8.setStartDate(LocalDate.of(2015, 6, 10));
        staff8.setStudent(true);
        Staff staff9 = new Staff("Joachim", "Henau");
        staff9.setStartDate(LocalDate.of(2007,9,18));

        staffMembers.add(staff1);
        staffMembers.add(staff2);
        staffMembers.add(staff3);
        staffMembers.add(staff4);
        staffMembers.add(staff5);
        staffMembers.add(staff6);
        staffMembers.add(staff7);
        staffMembers.add(staff8);
        staffMembers.add(staff9);
        return staffMembers;
    }

    private ArrayList<Visitor> fillVisitors() {
        ArrayList<Visitor> visitors = new ArrayList<>();
        Visitor visitor1 = new Visitor("Dominik", "Mioens");
        visitor1.setYearOfBirth(2001);
        Visitor visitor2 = new Visitor("Zion", "Noops");
        visitor2.setYearOfBirth(1996);
        Visitor visitor3 = new Visitor("Maria", "Bonetta");
        visitor3.setYearOfBirth(1998);
        Visitor visitor4 = new Visitor("Jef", "Ceulemans");
        visitor4.setYearOfBirth(2004);
        visitors.add(visitor1);
        visitors.add(visitor2);
        visitors.add(visitor3);
        visitors.add(visitor4);
        visitors.get(0).addToWishList("Dolphin");
        visitors.get(0).addToWishList("Snake");
        visitors.get(1).addToWishList("Lion");
        visitors.get(1).addToWishList("Eagle");
        visitors.get(1).addToWishList("Monkey");
        visitors.get(1).addToWishList("Elephant");
        visitors.get(2).addToWishList("Turtle");
        visitors.get(3).addToWishList("Dog");
        visitors.get(3).addToWishList("Cat");
        visitors.get(3).addToWishList("Jaguar");


        return visitors;
    }

    private ArrayList<Zoo> fillZoos() {
        ArrayList<Zoo> zoos = new ArrayList<>();
        Zoo zoo1 = new Zoo("Antwerp Zoo");
        Zoo zoo2 = new Zoo("Bellewaerde");
        Zoo zoo3 = new Zoo("Plankendael Zoo");
        AnimalWorld animalWorld1 = new AnimalWorld("Aquarium");
        AnimalWorld animalWorld2 = new AnimalWorld("Reptiles");
        AnimalWorld animalWorld3 = new AnimalWorld("Monkeys");
        animalWorld1.setNumberOfAnimals(1250);
        animalWorld2.setNumberOfAnimals(500);
        animalWorld3.setNumberOfAnimals(785);
        animalWorld1.setPhoto("/img/aquarium.jpg");
        animalWorld2.setPhoto("/img/reptiles.jpg");
        animalWorld3.setPhoto("/img/monkeys.jpg");
        animalWorld1.setResponsible(staffArrayList.get(0));
        animalWorld2.setResponsible(staffArrayList.get(1));
        animalWorld3.setResponsible(staffArrayList.get(2));
        zoo1.addAnimalWorld(animalWorld1);
        zoo1.addAnimalWorld(animalWorld2);
        zoo1.addAnimalWorld(animalWorld3);
        zoo2.addAnimalWorld(animalWorld1);
        zoo2.addAnimalWorld(animalWorld2);
        zoo3.addAnimalWorld(animalWorld1);
        zoo3.addAnimalWorld(animalWorld3);
        zoos.add(zoo1);
        zoos.add(zoo2);
        zoos.add(zoo3);
        return zoos;
    }


}
