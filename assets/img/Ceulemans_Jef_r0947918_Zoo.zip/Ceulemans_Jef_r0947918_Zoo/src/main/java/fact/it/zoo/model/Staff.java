/*Jef Ceulemans r0947918*/
package fact.it.zoo.model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Staff extends Person {

    private LocalDate startDate;
    private boolean student;

    public Staff(String firstName, String surName) {
        super(firstName, surName);
        startDate = LocalDate.now();
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public boolean isStudent() {
        return student;
    }

    public void setStudent(Boolean student) {
        this.student = student;
    }

    public String toString() {

        DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String information = "";

        if (student) {
            information = "Staff member " + super.toString() + " (working student) is employed since " +
                    getStartDate().format(dt) ;

        } else {
            information = "Staff member " + super.toString() + " is employed since " + getStartDate().format(dt) ;
        }


        return information;

    }

}
